package com.example.project2020;


import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Point;
import android.graphics.Rect;
import android.os.Build;
import android.os.Handler;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;


import androidx.annotation.RequiresApi;


public class GameView extends View {
    // add setting button using X and Y from touch listener
    @RequiresApi(api = Build.VERSION_CODES.O)
    public void onClick(View view) {
        view.requestPointerCapture();
    }
    public boolean onCapturedPointerEvent(MotionEvent motionEvent) {
        float verticalOffset = motionEvent.getY();
        System.out.println(verticalOffset);
        return true;
    }
    public boolean onCapturedPointer (View view, MotionEvent motionEvent) {
        // Get the coordinates required by your app

        float horizontalOffset = motionEvent.getX();
        System.out.println(horizontalOffset);
        return true;
    }


    Handler handler;
    Runnable runnable;
    Rect rect;
    long startTime, timeInMilliseconds = 0;
    Handler customHandler = new Handler();
    Bitmap background, apple,Bow,settings;
    Point point;
    Display display;
    final int Delay =100,Speed=100;
    final double speedHeight=10,Gravity=-10;
    int x = 5 ,ground, Helpx,Helpy;
    double arrowx,arrowy,pressTime;
    double yspeed,xspeed,yEquation,xEquation,Time=1;
    double z = 0;
    boolean check = true, touch = true, flag = false,up=false,first=true,settingpress=false,bound=true;
    int width, height, heartFrame = 0, bowFrame = 0,T=1; // work
    Bitmap[] bow, bowafter,arrow, heart1, heart3, heart2;
    View view;
    private MotionEvent event;

    public GameView(Context context) {
        super(context);


        handler = new Handler();
        runnable = new Runnable() {
            @Override
            public void run() {
                invalidate();
            }
        };

        background = BitmapFactory.decodeResource(getResources(), R.drawable.background);
        display = ((Activity) getContext()).getWindowManager().getDefaultDisplay();
        point = new Point();
        display.getSize(point);
        width = point.x;
        height = point.y;
        ground=height-200;
        rect = new Rect(0, 0, width, height);
        bow = new Bitmap[11];
        bowafter= new Bitmap[11];
        arrow= new Bitmap[11];
        heart1 = new Bitmap[2];
        heart2 = new Bitmap[2];
        heart3 = new Bitmap[2];
        settings = BitmapFactory.decodeResource(getResources(), R.drawable.finalsettingsbutton);
        arrow[5] = BitmapFactory.decodeResource(getResources(), R.drawable.arrow);
        arrow[6] = BitmapFactory.decodeResource(getResources(), R.drawable.arrow5);
        arrow[7] = BitmapFactory.decodeResource(getResources(), R.drawable.arrow10);
        arrow[8] = BitmapFactory.decodeResource(getResources(), R.drawable.arrow15);
        arrow[9] = BitmapFactory.decodeResource(getResources(), R.drawable.arrow20);
        arrow[10] = BitmapFactory.decodeResource(getResources(), R.drawable.arrow25);
        arrow[4] = BitmapFactory.decodeResource(getResources(), R.drawable.arrow_5);
        arrow[3] = BitmapFactory.decodeResource(getResources(), R.drawable.arrow_10);
        arrow[2] = BitmapFactory.decodeResource(getResources(), R.drawable.arrow_15);
        arrow[1] = BitmapFactory.decodeResource(getResources(), R.drawable.arrow_20);
        arrow[0] = BitmapFactory.decodeResource(getResources(), R.drawable.arrow_25);

        bowafter[5] = BitmapFactory.decodeResource(getResources(), R.drawable.bowbow);
        bowafter[6] = BitmapFactory.decodeResource(getResources(), R.drawable.bowbow5);
        bowafter[7] = BitmapFactory.decodeResource(getResources(), R.drawable.bowbow10);
        bowafter[8] = BitmapFactory.decodeResource(getResources(), R.drawable.bowbow15);
        bowafter[9] = BitmapFactory.decodeResource(getResources(), R.drawable.bowbow20);
        bowafter[10] = BitmapFactory.decodeResource(getResources(), R.drawable.bowbow25);
        bowafter[4] = BitmapFactory.decodeResource(getResources(), R.drawable.bowbow_5);
        bowafter[3] = BitmapFactory.decodeResource(getResources(), R.drawable.bowbow_10);
        bowafter[2] = BitmapFactory.decodeResource(getResources(), R.drawable.bowbow_15);
        bowafter[1] = BitmapFactory.decodeResource(getResources(), R.drawable.bowbow_20);
        bowafter[0] = BitmapFactory.decodeResource(getResources(), R.drawable.bowbow_25);

        bow[5] = BitmapFactory.decodeResource(getResources(), R.drawable.bow);
        bow[6] = BitmapFactory.decodeResource(getResources(), R.drawable.bow5);
        bow[7] = BitmapFactory.decodeResource(getResources(), R.drawable.bow10);
        bow[8] = BitmapFactory.decodeResource(getResources(), R.drawable.bow15);
        bow[9] = BitmapFactory.decodeResource(getResources(), R.drawable.bow20);
        bow[10] = BitmapFactory.decodeResource(getResources(), R.drawable.bow25);
        bow[4] = BitmapFactory.decodeResource(getResources(), R.drawable.bow_5);
        bow[3] = BitmapFactory.decodeResource(getResources(), R.drawable.bow_10);
        bow[2] = BitmapFactory.decodeResource(getResources(), R.drawable.bow_15);
        bow[1] = BitmapFactory.decodeResource(getResources(), R.drawable.bow_20);
        bow[0] = BitmapFactory.decodeResource(getResources(), R.drawable.bow_25);

        heart1[0] = BitmapFactory.decodeResource(getResources(), R.drawable.fullheart);
        heart2[0] = BitmapFactory.decodeResource(getResources(), R.drawable.fullheart);
        heart3[0] = BitmapFactory.decodeResource(getResources(), R.drawable.fullheart);
        heart1[1] = BitmapFactory.decodeResource(getResources(), R.drawable.emptyheart);
        heart2[1] = BitmapFactory.decodeResource(getResources(), R.drawable.emptyheart);
        heart3[1] = BitmapFactory.decodeResource(getResources(), R.drawable.emptyheart);
        apple = BitmapFactory.decodeResource(getResources(), R.drawable.apple);
    }


    protected void onDraw(Canvas canvas) {

        super.onDraw(canvas);

        canvas.drawBitmap(background, null, rect, null);
        canvas.drawBitmap(settings,width/30,height/25,null);
        canvas.drawBitmap(heart1[0], width * 7 / 8, height / 8, null);
        canvas.drawBitmap(heart2[0], width * 46 / 64, height / 8, null);
        canvas.drawBitmap(heart3[0], width * 51 / 64, height / 8, null);
        canvas.drawBitmap(apple, width * 7 / 8, height / 2, null);

        if (touch == true) {

            if (bowFrame < 10 && check == true) {
                bowFrame++;

            } else if (bowFrame == 10) {
                check = false;
                bowFrame--;
            } else if (bowFrame != 0) {
                bowFrame--;
            } else {
                check = true;

            }
        }
        if(!up)
            canvas.drawBitmap(bow[bowFrame], width / 9 - bow[bowFrame].getWidth() / 2, height * 16 / 32 - bow[bowFrame].getHeight() / 2, null);
        if (up) {


            if(first){
                pressTime=z;
                if(pressTime>1000)
                    pressTime=50;
                else{
                    pressTime= pressTime/20;
                }
                z=z/500;
                arrowx=width / 9 - bow[bowFrame].getWidth() / 2;
                switch (bowFrame){
                    case 6:
                        yspeed=(pressTime*Math.sin(5*0.01745));
                        xspeed=(pressTime*Math.cos(5*0.01745));
                        System.out.println("Case 6 "+pressTime*Math.sin(5*0.01745));
                        arrowy=height * 16 / 32 - bow[bowFrame].getHeight() / 2;
                        arrowx=width / 9 - bow[bowFrame].getWidth() / 2;
                        break;
                    case 1:
                        yspeed=(pressTime*Math.sin(10*0.01745));
                        xspeed=(pressTime*Math.cos(10*0.01745));
                        System.out.println("Case 1 "+pressTime*Math.sin(10*0.01745));
                        arrowy=height * 16 / 32 - bow[bowFrame].getHeight() / 2;
                        arrowx=width / 9 - bow[bowFrame].getWidth() / 2;
                        break;
                    case 0:
                        yspeed=(pressTime*Math.sin(-25*0.01745));
                        xspeed=(pressTime*Math.cos(-25*0.01745));
                        System.out.println("Case 0 "+pressTime*Math.sin(-25*0.01745));
                        arrowy=height * 16 / 32 - bow[bowFrame].getHeight() / 2;
                        arrowx=width / 9 - bow[bowFrame].getWidth() / 2;
                        break;
                    case 2:
                        yspeed=(pressTime*Math.sin(-15*0.01745));
                        xspeed=(pressTime*Math.cos(-15*0.01745));
                        System.out.println("Case 2 "+pressTime*Math.sin(-15*0.01745));
                        arrowy=height * 16 / 32 - bow[bowFrame].getHeight() / 2;
                        break;
                    case 3:
                        yspeed=(pressTime*Math.sin(-10*0.01745));
                        xspeed=(pressTime*Math.cos(-10*0.01745));
                        System.out.println("Case 3 "+pressTime*Math.sin(-10*0.01745));
                        arrowy=height * 16 / 32 - bow[bowFrame].getHeight() / 2;
                        arrowx=width / 9 - bow[bowFrame].getWidth() / 2;
                        break;
                    case 4:
                        yspeed=(pressTime*Math.sin(-5*0.01745));
                        xspeed=(pressTime*Math.cos(-5*0.01745));
                        System.out.println("Case 4 "+pressTime*Math.sin(-5*0.01745));
                        arrowy=height * 16 / 32 - bow[bowFrame].getHeight() / 2;
                        arrowx=width / 9 - bow[bowFrame].getWidth() / 2;
                        break;
                    case 5:
                        yspeed=0;
                        System.out.println("Case 5 ");
                        arrowy=height * 16 / 32 - bow[bowFrame].getHeight() / 2;
                        arrowx=width / 9 - bow[bowFrame].getWidth() / 2;
                        break;
                    case 7:
                        yspeed=(pressTime*Math.sin(10*0.01745));
                        xspeed=(pressTime*Math.cos(10*0.01745));
                        System.out.println("Case 7 "+pressTime*Math.sin(10*0.01745));
                        arrowy=height * 16 / 32 - bow[bowFrame].getHeight() / 2;
                        arrowx=width / 9 - bow[bowFrame].getWidth() / 2;
                        break;
                    case 8:
                        yspeed=(pressTime*Math.sin(15*0.01745));
                        yspeed=(pressTime*Math.cos(15*0.01745));
                        System.out.println("Case 8 "+pressTime*Math.sin(15*0.01745));
                        arrowy=height * 16 / 32 - bow[bowFrame].getHeight() / 2;
                        arrowx=width / 9 - bow[bowFrame].getWidth() / 2;
                        break;
                    case 9:
                        yspeed=(pressTime*Math.sin(20*0.01745));
                        xspeed=(pressTime*Math.cos(20*0.01745));
                        System.out.println("Case 9 "+pressTime*Math.sin(20*0.01745));
                        arrowy=height * 16 / 32 - bow[bowFrame].getHeight() / 2;
                        arrowx=width / 9 - bow[bowFrame].getWidth() / 2;
                        break;
                    case 10:
                        yspeed=(pressTime*Math.sin(25*0.01745));
                        xspeed=(pressTime*Math.cos(25*0.01745));
                        System.out.println("Case 10 "+pressTime*Math.sin(25*0.01745));
                        arrowy=height * 16 / 32 - bow[bowFrame].getHeight() / 2;
                        arrowx=width / 9 - bow[bowFrame].getWidth() / 2;
                        break;
                }
            }
            yEquation=arrowy;
            xEquation=arrowx;
            if(Time==1)
                xEquation+=10;
            if(z!=0)
                first=false;
          if(bound&&true){
              bound=false;
             // System.out.println("error?");
          }



            if( (xEquation+(xspeed+pressTime)*Time*3/2)>1055&&Helpy!=540){
                xEquation=1055;
            }
            else{
                if(Helpy==540){
                 //   System.out.println("me problem");
                    xEquation= Helpx;
                }
                if(Helpy!=540){
                xEquation+=(xspeed+pressTime)*Time*3/2;
                    System.out.println("xEQuation1 "+yEquation);
                Helpx =(int)xEquation;
                }
            }
            if((yEquation+((-yspeed-(yspeed/Math.abs(yspeed))*pressTime)*Time-((Gravity/2)*Time*Time)))>540&&xEquation!=1055) {
                yEquation=540;
            }
            else{
                if(xEquation>1055) {
                    yEquation = Helpy;
                    System.out.println("me not problem");
                }
                if(xEquation<1055){
                   // System.out.println("X EQuation "+xEquation);
                    yEquation+=((-yspeed-(yspeed/Math.abs(yspeed))*pressTime)*Time-((Gravity/2)*Time*Time));
                    Helpy=(int)yEquation;
                }


            }
          System.out.println("yEquation "+yEquation);




            canvas.drawBitmap(bowafter[bowFrame], width / 9 - bow[bowFrame].getWidth() / 2, height * 16 / 32 - bow[bowFrame].getHeight() / 2, null);
            canvas.drawBitmap(arrow[bowFrame], (int)xEquation,(int)yEquation, null);
            Time+=1;
        }
        handler.postDelayed(runnable, Delay);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        float Ytouch = event.getY();// y
        float Xtouch= event.getX();//x
        System.out.println("Y:   "+ Ytouch);
        System.out.println("X:    "+Xtouch);
        long eventDuration = android.os.SystemClock.elapsedRealtime() - event.getDownTime();
        if(T%4==0&&T!=1){
            System.out.println("T: "+T);
            System.out.println("Event Duration:  "+eventDuration);
            System.out.println((int)eventDuration);
            z=(int)eventDuration;
            up=true;
        }


        int action = event.getAction();
        if(!(Xtouch>43&&Xtouch<119&&Ytouch>25&&Ytouch<108)){
            T++;
            settingpress=false;
        }
        else{
            settingpress=true;
        }
        if (action == MotionEvent.ACTION_DOWN&&!flag&&!settingpress) {
            touch = false;

            flag=true;

        }

        return true;


    }
}

