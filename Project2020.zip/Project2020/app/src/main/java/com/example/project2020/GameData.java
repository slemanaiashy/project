package com.example.project2020;

public class GameData {
    double AveragePlayersAge;
    double AverageHoursplayedPerday;
}
